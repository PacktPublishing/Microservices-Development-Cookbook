class AttachmentsService
    def initialize(params)
    end

    def upload
    end

    def delete!
    end
end
